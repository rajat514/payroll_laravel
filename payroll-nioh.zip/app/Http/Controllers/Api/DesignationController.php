<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Designation;
use Illuminate\Http\Request;

class DesignationController extends Controller
{
    function index()
    {
        $data = Designation::all();
        return response()->json(['data' => $data]);
    }

    function store(Request $request)
    {
        $fields = $request->validate([
            'name' => 'required|string|max:191',
            'options' => 'nullable|array',
            'options.*' => 'string|max:100'
        ]);

        $fields['added_by'] = auth()->id();

        try {
            $designation = Designation::create($fields);
            return response()->json(['successMsg' => "Designation created!", 'data' => $designation]);
        } catch (\Exception $e) {
            return response()->json(['errorMsg' => $e->getMessage()], 500);
        }
    }
}
